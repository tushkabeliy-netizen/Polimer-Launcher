# ПОЛИМЕР — Android launcher prototype

Retro-futurist Soviet-inspired Android home-screen prototype for Android 8.0+.

## Included
- Home-screen activity that can be selected as the default launcher.
- Digital clock, Russian date and live countdown to the next New Year.
- Ten bundled image resources and a gallery to preview/select them.
- Manual wallpaper controls for home screen and lock screen (subject to Android/OEM policy).
- App catalog and quick launcher shortcuts.
- Daily wallpaper worker (Android WorkManager; execution is periodic and battery-optimized, not guaranteed at an exact midnight).
- Custom app icon.

## Build
Open this folder in Android Studio, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

The generated APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Important Android limitations
- A third-party launcher cannot replace Samsung's secure lock-screen UI. It can set lock-screen wallpaper where the device permits it; the countdown/clock on the lock screen remains controlled by Android/One UI.
- Android WorkManager periodic work is inexact (minimum interval 15 minutes, subject to Doze/battery optimization). The daily image change may occur later than midnight.
- Android 11+ package visibility rules limit app discovery to launcher activities, which this project declares in `<queries>`.

Package: `ru.polymer.launcher`  |  Version: `0.3`
