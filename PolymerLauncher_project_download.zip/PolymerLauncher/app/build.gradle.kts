plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "ru.polymer.launcher"; compileSdk = 35
    defaultConfig { applicationId = "ru.polymer.launcher"; minSdk = 26; targetSdk = 35; versionCode = 1; versionName = "0.3" }
}


dependencies {
    implementation("androidx.work:work-runtime-ktx:2.10.0")
}
