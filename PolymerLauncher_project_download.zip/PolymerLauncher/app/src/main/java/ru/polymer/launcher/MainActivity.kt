package ru.polymer.launcher

import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.work.*
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val images = intArrayOf(R.drawable.city_01,R.drawable.city_02,R.drawable.city_03,R.drawable.city_04,R.drawable.city_05,R.drawable.city_06,R.drawable.city_07,R.drawable.city_08,R.drawable.city_09,R.drawable.city_10)
    private val names = arrayOf("ВОЛГОГРАД / РОДИНА-МАТЬ", "МОСКВА", "САНКТ-ПЕТЕРБУРГ", "СЕВАСТОПОЛЬ", "СОВЕТСКИЙ МЕМОРИАЛ", "ГОРОД БУДУЩЕГО", "МОНУМЕНТ ПОБЕДЫ", "СОВЕТСКАЯ АРХИТЕКТУРА", "ВОЕННО-МОРСКОЙ ГОРОД", "РЖЕВСКИЙ МЕМОРИАЛ")
    private lateinit var root: FrameLayout
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var countdown: TextView
    private lateinit var title: TextView
    private lateinit var counter: TextView
    private var selected = (Calendar.getInstance().get(Calendar.DAY_OF_YEAR)-1)%10
    private val tick = object : Runnable { override fun run() { updateTime(); root.postDelayed(this,1000) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selected = getSharedPreferences("polymer", MODE_PRIVATE).getInt("selected", (Calendar.getInstance().get(Calendar.DAY_OF_YEAR)-1)%10).coerceIn(0,9)
        scheduleDailyWallpaper(); buildUi(); updateTime(); root.post(tick)
    }
    override fun onDestroy() { root.removeCallbacks(tick); super.onDestroy() }

    private fun buildUi() {
        root=FrameLayout(this); root.setBackgroundResource(images[selected]); setContentView(root)
        val shade=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(22,30,22,18); setBackground(GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xD9081722.toInt(),0xA9081722.toInt(),0xE9081722.toInt()))) }
        val top=TextView(this).apply { text="◆  ПОЛИМЕР     /     НИИ-3826"; setTextColor(0xFFFF5A50.toInt()); textSize=12f; typeface=Typeface.MONOSPACE; letterSpacing=.08f }
        val sub=TextView(this).apply { text="ЕДИНАЯ НАУЧНО-ИНФОРМАЦИОННАЯ СИСТЕМА"; setTextColor(0xFFB9D8E8.toInt()); textSize=9f; typeface=Typeface.MONOSPACE; setPadding(0,5,0,18) }
        clock=TextView(this).apply { textSize=57f; setTextColor(Color.WHITE); typeface=Typeface.create("sans-serif-condensed",Typeface.BOLD); letterSpacing=.035f }
        date=TextView(this).apply { setTextColor(0xFFB9D8E8.toInt()); textSize=12f; typeface=Typeface.MONOSPACE; setPadding(1,0,0,12) }
        countdown=TextView(this).apply { textSize=14f; setTextColor(0xFFFFD16B.toInt()); typeface=Typeface.MONOSPACE; setPadding(12,10,12,10); background=panel(0x99202F3A.toInt(),0x88FFC45C.toInt()) }
        val line=View(this).apply { setBackgroundColor(0xCCF04A43.toInt()) }
        title=TextView(this).apply { setTextColor(Color.WHITE); textSize=15f; typeface=Typeface.create("sans-serif-condensed",Typeface.BOLD); setPadding(0,12,0,3) }
        counter=TextView(this).apply { setTextColor(0xFFFF6258.toInt()); textSize=10f; typeface=Typeface.MONOSPACE; setPadding(0,0,0,10) }
        val spacer=Space(this)
        val nav=LinearLayout(this).apply { gravity=Gravity.CENTER; orientation=LinearLayout.HORIZONTAL }
        nav.addView(makeButton("◀ ПРЕДЫДУЩАЯ"){change(-1)}, LinearLayout.LayoutParams(0,48,1f))
        nav.addView(makeButton("СЛЕДУЮЩАЯ ▶"){change(1)}, LinearLayout.LayoutParams(0,48,1f))
        val shortcuts=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER; setPadding(0,10,0,8) }
        val shortcutData=listOf(Triple("▦","ГАЛЕРЕЯ"){showGallery()},Triple("▤","ПРИЛОЖЕНИЯ"){showApps()},Triple("◉","ОБОИ"){setWallpapers()},Triple("⚙","ЦИКЛ"){showSchedule()})
        shortcutData.forEach { (symbol,label,action) -> shortcuts.addView(shortcut(symbol,label,action),LinearLayout.LayoutParams(0,76,1f)) }
        val footer=TextView(this).apply { text="СИСТЕМА АКТИВНА  •  АРХИВ ИЗОБРАЖЕНИЙ  •  1955—2026"; gravity=Gravity.CENTER; setTextColor(0x99D2E2EA.toInt()); textSize=8f; typeface=Typeface.MONOSPACE; setPadding(0,8,0,0) }
        shade.addView(top); shade.addView(sub); shade.addView(clock); shade.addView(date); shade.addView(countdown)
        shade.addView(line,LinearLayout.LayoutParams(-1,1).apply{topMargin=16;bottomMargin=5})
        shade.addView(spacer,LinearLayout.LayoutParams(1,0,1f)); shade.addView(title); shade.addView(counter); shade.addView(nav); shade.addView(shortcuts); shade.addView(footer)
        root.addView(shade,FrameLayout.LayoutParams(-1,-1)); refreshTitle()
    }
    private fun panel(color:Int,stroke:Int)=GradientDrawable().apply{cornerRadius=8f;setColor(color);setStroke(1,stroke)}
    private fun makeButton(label:String, action:()->Unit)=Button(this).apply { text=label; textSize=9f; isAllCaps=false; setTextColor(Color.WHITE); background=panel(0xDD18364A.toInt(),0xCC4A829B.toInt()); setOnClickListener{action()} }
    private fun shortcut(symbol:String,label:String,action:()->Unit):View = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setOnClickListener{action()}; val icon=TextView(this@MainActivity).apply{text=symbol;textSize=23f;gravity=Gravity.CENTER;setTextColor(0xFFFF665B.toInt());background=panel(0xCC172D3B.toInt(),0xAAE34B45.toInt())}; addView(icon,LinearLayout.LayoutParams(48,42)); addView(TextView(this@MainActivity).apply{text=label;textSize=8f;gravity=Gravity.CENTER;setTextColor(0xFFE2EDF2.toInt());typeface=Typeface.MONOSPACE;setPadding(0,5,0,0)}) }
    private fun change(delta:Int) { selected=(selected+delta+images.size)%images.size; saveSelection(); root.setBackgroundResource(images[selected]); refreshTitle() }
    private fun saveSelection(){getSharedPreferences("polymer",MODE_PRIVATE).edit().putInt("selected",selected).apply()}
    private fun refreshTitle(){ title.text=names[selected]; counter.text="АРХИВНАЯ ЗАСТАВКА № %02d / 10".format(selected+1) }
    private fun updateTime(){ val now=Calendar.getInstance(); clock.text="%02d:%02d:%02d".format(now.get(Calendar.HOUR_OF_DAY),now.get(Calendar.MINUTE),now.get(Calendar.SECOND)); date.text=SimpleDateFormat("EEEE, d MMMM yyyy",Locale("ru")).format(now.time).uppercase(Locale("ru")); val target=Calendar.getInstance().apply { set(Calendar.MONTH,Calendar.JANUARY);set(Calendar.DAY_OF_MONTH,1);set(Calendar.HOUR_OF_DAY,0);set(Calendar.MINUTE,0);set(Calendar.SECOND,0);set(Calendar.MILLISECOND,0);if(timeInMillis<=now.timeInMillis)add(Calendar.YEAR,1) }; val sec=((target.timeInMillis-now.timeInMillis)/1000).coerceAtLeast(0); countdown.text="ДО НОВОГО ГОДА     %d ДНЕЙ   %02d:%02d:%02d".format(sec/86400,(sec%86400)/3600,(sec%3600)/60,sec%60) }
    private fun setWallpapers(){ try { WallpaperManager.getInstance(this).setResource(images[selected],WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK); Toast.makeText(this,"Обои рабочего стола и экрана блокировки установлены",Toast.LENGTH_LONG).show() } catch(e:Exception){ Toast.makeText(this,"Не удалось установить обои: ${e.localizedMessage}",Toast.LENGTH_LONG).show() } }
    private fun showGallery(){ val rows=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(10,4,10,4)}; images.indices.forEach { i -> val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(5,7,5,7);setOnClickListener{selected=i;saveSelection();root.setBackgroundResource(images[i]);refreshTitle();galleryDialog?.dismiss()}}; val preview=ImageView(this@MainActivity).apply{setImageResource(images[i]);scaleType=ImageView.ScaleType.CENTER_CROP};row.addView(preview,LinearLayout.LayoutParams(104,62));row.addView(TextView(this@MainActivity).apply{text="%02d  /  %s".format(i+1,names[i]);textSize=11f;setTextColor(Color.WHITE);typeface=Typeface.MONOSPACE;setPadding(12,0,0,0)},LinearLayout.LayoutParams(0,62,1f));rows.addView(row);val divider=View(this).apply{setBackgroundColor(0x553E6578)};rows.addView(divider,LinearLayout.LayoutParams(-1,1)) }; val scroll=ScrollView(this).apply{addView(rows);setBackgroundColor(0xFF102330.toInt())};galleryDialog=AlertDialog.Builder(this).setTitle("АРХИВ ЗАСТАВОК / 10 ОБРАЗЦОВ").setView(scroll).setNegativeButton("ЗАКРЫТЬ",null).create();galleryDialog?.show() }
    private var galleryDialog:AlertDialog?=null
    private fun showApps(){ val pm=packageManager; val intent=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER); val apps=pm.queryIntentActivities(intent,0).sortedBy{it.loadLabel(pm).toString()}; val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; for(a in apps){ val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(8,5,8,5)}; val icon=ImageView(this).apply{setImageDrawable(a.loadIcon(pm))}; row.addView(icon,LinearLayout.LayoutParams(42,42)); row.addView(TextView(this).apply{text=a.loadLabel(pm);textSize=15f;setTextColor(Color.WHITE);setPadding(14,8,8,8)},LinearLayout.LayoutParams(0,50,1f));row.setOnClickListener{startActivity(pm.getLaunchIntentForPackage(a.activityInfo.packageName))};list.addView(row) }; val scroll=ScrollView(this).apply{addView(list);setBackgroundColor(0xFF142A38.toInt())}; AlertDialog.Builder(this).setTitle("ПРИЛОЖЕНИЯ СИСТЕМЫ").setView(scroll).setPositiveButton("ЗАКРЫТЬ",null).show() }
    private fun showSchedule(){ val labels=arrayOf("Понедельник — Волгоград", "Вторник — Москва", "Среда — Санкт-Петербург", "Четверг — Севастополь", "Пятница — Советский мемориал", "Суббота — Город будущего", "Воскресенье — Ржевский мемориал"); AlertDialog.Builder(this).setTitle("НЕДЕЛЬНЫЙ ЦИКЛ").setItems(labels){_,which->selected=intArrayOf(0,1,2,3,4,5,9)[which];saveSelection();root.setBackgroundResource(images[selected]);refreshTitle()}.setNegativeButton("ОТМЕНА",null).show() }
    private fun scheduleDailyWallpaper(){ val request=PeriodicWorkRequestBuilder<DailyWallpaperWorker>(24,TimeUnit.HOURS).build(); WorkManager.getInstance(this).enqueueUniquePeriodicWork("polymer_daily_wallpaper",ExistingPeriodicWorkPolicy.UPDATE,request) }
}

class DailyWallpaperWorker(context: android.content.Context, params: WorkerParameters): Worker(context,params) {
    override fun doWork(): Result { return try { val ids=intArrayOf(R.drawable.city_01,R.drawable.city_02,R.drawable.city_03,R.drawable.city_04,R.drawable.city_05,R.drawable.city_06,R.drawable.city_07,R.drawable.city_08,R.drawable.city_09,R.drawable.city_10); val day=Calendar.getInstance().get(Calendar.DAY_OF_WEEK); val index=(day+5)%7; val mapping=intArrayOf(0,1,2,3,4,5,9); WallpaperManager.getInstance(applicationContext).setResource(ids[mapping[index]],WallpaperManager.FLAG_SYSTEM); Result.success() } catch(e:Exception){ Result.retry() } }
}
